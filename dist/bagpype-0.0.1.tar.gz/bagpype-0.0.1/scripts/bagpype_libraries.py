pip install pandas 
pip install sklearn
pip install matplotlib
pip install numpy
pip install scipy
pip install sklearn
pip install pandas 
pip install warnings
pip install seaborn
pip install python-igraph
pip install subprocess
pip install pyyaml
pip install importlib
python3 -m pip install ipykernel
python3 -m ipykernel install --user 
brew install parallel 



